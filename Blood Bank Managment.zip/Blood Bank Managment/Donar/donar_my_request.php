<?php
session_start();
if (!isset($_SESSION['donor_id'])) { header("Location: Donar_Login.php"); exit; }
$conn = new mysqli("localhost","root","","bbm");
if ($conn->connect_error) { die("Connection failed: ".$conn->connect_error); }

$donor_id = $_SESSION['donor_id'];
$result = $conn->query("SELECT * FROM donation_requests WHERE donor_id=$donor_id ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Requests</title>
    <style>
        body { margin:0; font-family: Arial, sans-serif; background:#f4f6f9; }
        .header { background:#c62828; color:white; padding:15px; text-align:center; font-size:22px; }
        .container { display:flex; }
        .sidebar { width:200px; background:#333; height:100vh; padding-top:20px; }
        .sidebar a { display:block; padding:12px; color:white; text-decoration:none; }
        .sidebar a:hover { background:#444; }
        .main { flex:1; padding:20px; }
        table { width:100%; border-collapse:collapse; background:white; box-shadow:0 2px 6px rgba(0,0,0,0.2); }
        th, td { padding:10px; border:1px solid #ddd; text-align:center; }
        th { background:#eee; }
    </style>
</head>
<body>
    <div class="header">My Requests</div>
    <div class="container">
        <div class="sidebar">
            <a href="donar_dashboard.php">Dashboard</a>
            <a href="donate_request.php">Make Request</a>
            <a href="donar_my_request.php">My Requests</a>
            <a href="profile.php">My Profile</a>
            <a href="d_logout.php">Logout</a>
        </div>
        <div class="main">
            <h2>Donation Requests</h2>
            <table>
                <tr>
                    <th>ID</th><th>Blood Group</th><th>Units</th><th>Date</th><th>Time</th><th>Center</th><th>Status</th><th>Notes</th>
                </tr>
                <?php while($row=$result->fetch_assoc()){ ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo $row['blood_group']; ?></td>
                    <td><?php echo $row['units']; ?></td>
                    <td><?php echo $row['donation_date']; ?></td>
                    <td><?php echo $row['donation_time']; ?></td>
                    <td><?php echo $row['donation_center']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo $row['notes']; ?></td>
                </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</body>
</html>
