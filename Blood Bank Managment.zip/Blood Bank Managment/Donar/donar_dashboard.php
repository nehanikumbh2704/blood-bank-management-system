<?php
session_start();
if (!isset($_SESSION['donor_id'])) {
    header("Location: Donar_Login.php");
    exit;
}
$conn = new mysqli("localhost", "root", "", "bbm");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$donor_id = $_SESSION['donor_id'];
$name = $_SESSION['donor_name'];

// count requests
$pending = $conn->query("SELECT COUNT(*) AS c FROM donation_requests WHERE donor_id=$donor_id AND status='Pending'")->fetch_assoc()['c'];
$approved = $conn->query("SELECT COUNT(*) AS c FROM donation_requests WHERE donor_id=$donor_id AND status='Approved'")->fetch_assoc()['c'];
$rejected = $conn->query("SELECT COUNT(*) AS c FROM donation_requests WHERE donor_id=$donor_id AND status='Rejected'")->fetch_assoc()['c'];
$completed = $conn->query("SELECT COUNT(*) AS c FROM donation_requests WHERE donor_id=$donor_id AND status='Completed'")->fetch_assoc()['c'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Donor Dashboard</title>
    <style>
        body { margin:0; font-family: Arial, sans-serif; background:#f4f6f9; }
        .header { background:#c62828; color:white; padding:15px; text-align:center; font-size:22px; }
        .container { display:flex; }
        .sidebar { width:200px; background:#333; height:100vh; padding-top:20px; }
        .sidebar a { display:block; padding:12px; color:white; text-decoration:none; }
        .sidebar a:hover { background:#444; }
        .main { flex:1; padding:20px; }
        .stats { display:grid; grid-template-columns: repeat(4, 1fr); gap:20px; margin-top:20px; }
        .card { padding:20px; border-radius:8px; text-align:center; font-size:18px; font-weight:bold; color:white; }
        .pending { background:#fbc02d; }
        .approved { background:#29b6f6; }
        .rejected { background:#e53935; }
        .completed { background:#43a047; }
    </style>
</head>
<body>
    <div class="header">Welcome, <?php echo $name; ?> </div>
    <div class="container">
        <div class="sidebar">
            <a href="donar_dashboard.php">Dashboard</a>
            <a href="donate_request.php">Make Donation Request</a>
            <a href="donar_my_request.php">My Requests</a>
            <a href="profile.php">My Profile</a>
            <a href="d_logout.php">Logout</a>
        </div>
        <div class="main">
            <h2>My Donation Stats</h2>
            <div class="stats">
                <div class="card pending">Pending<br><?php echo $pending; ?></div>
                <div class="card approved">Approved<br><?php echo $approved; ?></div>
                <div class="card rejected">Rejected<br><?php echo $rejected; ?></div>
                <div class="card completed">Completed<br><?php echo $completed; ?></div>
            </div>
        </div>
    </div>
</body>
</html>
