<?php
session_start();
if (!isset($_SESSION['donor_id'])) { header("Location: Donar_Login.php"); exit; }
$conn = new mysqli("localhost","root","","bbm");
if ($conn->connect_error) { die("Connection failed: ".$conn->connect_error); }

$donor_id = $_SESSION['donor_id'];

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $name=$_POST['full_name'];
    $phone=$_POST['phone'];
    $address=$_POST['address'];
    $bg=$_POST['blood_group'];
    $password=$_POST['password'];

    if(!empty($password)){
        $password=password_hash($password,PASSWORD_DEFAULT);
        $sql="UPDATE donors SET full_name='$name', phone='$phone', address='$address', blood_group='$bg', password_hash='$password' WHERE d_id=$donor_id";
    } else {
        $sql="UPDATE donors SET full_name='$name', phone='$phone', address='$address', blood_group='$bg' WHERE d_id=$donor_id";
    }

    if($conn->query($sql)){ $_SESSION['donor_name']=$name; echo "<script>alert('Profile updated!');</script>"; }
}

$donor=$conn->query("SELECT * FROM donors WHERE d_id=$donor_id")->fetch_assoc();
?>
<!DOCTYPE html>
<html>
<head>
    <title>My Profile</title>
    <style>
        body { margin:0; font-family: Arial, sans-serif; background:#f4f6f9; }
        .header { background:#c62828; color:white; padding:15px; text-align:center; font-size:22px; }
        .container { display:flex; }
        .sidebar { width:200px; background:#333; height:100vh; padding-top:20px; }
        .sidebar a { display:block; padding:12px; color:white; text-decoration:none; }
        .sidebar a:hover { background:#444; }
        .main { flex:1; padding:20px; }
        .form-box { background:white; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.2); max-width:500px; }
        input { width:100%; padding:10px; margin:8px 0; border:1px solid #ccc; border-radius:5px; }
        button { background:#c62828; color:white; border:none; padding:12px; width:100%; border-radius:5px; font-size:16px; }
        button:hover { background:#a11414; cursor:pointer; }
    </style>
</head>
<body>
    <div class="header">My Profile</div>
    <div class="container">
        <div class="sidebar">
            <a href="donar_dashboard.php">Dashboard</a>
            <a href="donate_request.php">Make Request</a>
            <a href="donar_my_request.php">My Requests</a>
            <a href="profile.php">My Profile</a>
            <a href="d_logout.php">Logout</a>
        </div>
        <div class="main">
            <div class="form-box">
                <form method="POST">
                    Full Name: <input type="text" name="full_name" value="<?php echo $donor['full_name']; ?>" required>
                    Email: <input type="email" value="<?php echo $donor['email']; ?>" readonly>
                    Phone: <input type="text" name="phone" value="<?php echo $donor['phone']; ?>" required>
                    Address: <input type="text" name="address" value="<?php echo $donor['address']; ?>" required>
                    Blood Group: <input type="text" name="blood_group" value="<?php echo $donor['blood_group']; ?>" required>
                    New Password (optional): <input type="password" name="password">
                    <button type="submit">Update Profile</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
