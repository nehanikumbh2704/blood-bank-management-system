<?php
session_start();
if (!isset($_SESSION['donor_id'])) { header("Location: Donar_Login.php"); exit; }
$conn = new mysqli("localhost","root","","bbm");
if ($conn->connect_error) { die("Connection failed: ".$conn->connect_error); }

if ($_SERVER['REQUEST_METHOD']=="POST") {
    $donor_id = $_SESSION['donor_id'];
    $bg = $_POST['blood_group'];
    $units = $_POST['units'];
    $date = $_POST['donation_date'];
    $time = $_POST['donation_time'];
    $center = $_POST['donation_center'];
    $notes = $_POST['notes'];

    $sql = "INSERT INTO donation_requests 
            (donor_id,blood_group,units,donation_date,donation_time,donation_center,notes,status)
            VALUES 
            ('$donor_id','$bg','$units','$date','$time','$center','$notes','Pending')";
    if ($conn->query($sql)) {
        echo "<script>alert('Donation Request Submitted!');window.location='donar_my_request.php';</script>";
    } else {
        echo "Error: ".$conn->error;
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Create Donation Request</title>
    <style>
        body { margin:0; font-family: Arial, sans-serif; background:#f4f6f9; }
        .header { background:#c62828; color:white; padding:15px; text-align:center; font-size:22px; }
        .container { display:flex; }
        .sidebar { width:200px; background:#333; height:100vh; padding-top:20px; }
        .sidebar a { display:block; padding:12px; color:white; text-decoration:none; }
        .sidebar a:hover { background:#444; }
        .main { flex:1; padding:20px; }
        .form-box { background:white; padding:20px; border-radius:8px; box-shadow:0 2px 6px rgba(0,0,0,0.2); max-width:500px; }
        h2 { margin-bottom:15px; }
        input, textarea { width:100%; padding:10px; margin:8px 0; border:1px solid #ccc; border-radius:5px; }
        button { background:#c62828; color:white; border:none; padding:12px; width:100%; border-radius:5px; font-size:16px; }
        button:hover { background:#a11414; cursor:pointer; }
    </style>
</head>
<body>
    <div class="header">Create Donation Request</div>
    <div class="container">
        <div class="sidebar">
            <a href="donar_dashboard.php">Dashboard</a>
            <a href="donate_request.php">Make Request</a>
            <a href="donar_my_request.php">My Requests</a>
            <a href="profile.php">My Profile</a>
            <a href="d_logout.php">Logout</a>
        </div>
        <div class="main">
            <div class="form-box">
                <h2>Donation Request Form</h2>
                <form method="POST">
                    Blood Group: <input type="text" name="blood_group" required>
                    Units: <input type="number" name="units" required>
                    Date: <input type="date" name="donation_date" required>
                    Time: <input type="time" name="donation_time" required>
                    Center: <input type="text" name="donation_center" required>
                    Notes: <textarea name="notes"></textarea>
                    <button type="submit">Submit Request</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
