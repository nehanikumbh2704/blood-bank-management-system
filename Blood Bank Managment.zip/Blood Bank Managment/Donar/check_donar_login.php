

 <?php
session_start();
$conn = new mysqli("localhost", "root", "", "bbm");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM donors WHERE email='$email'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
    $row = $result->fetch_assoc();
    if (password_verify($password, $row['password_hash'])) {
        $_SESSION['donor_id'] = $row['d_id'];
        $_SESSION['donor_name'] = $row['full_name'];
        header("Location: donar_dashboard.php");
        exit;
    }
}
echo "Invalid login. <a href='Donar_Login.php'>Try again</a>";
?>

