

<?php
// connect to DB
$conn = new mysqli("localhost", "root", "", "bbm");
if ($conn->connect_error) { die("Connection failed: " . $conn->connect_error); }

$name = $_POST['full_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$address = $_POST['address'];
$blood_group = $_POST['blood_group'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

// check if email already exists
$sql = "SELECT * FROM donors WHERE email='$email'";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    echo "Email already registered. <a href='Donar_Login.php'>Login here</a>";
    exit;
}

// insert donor
$sql = "INSERT INTO donors (full_name, email, phone, address, blood_group, password_hash) 
        VALUES ('$name','$email','$phone','$address','$blood_group','$password')";

if ($conn->query($sql) === TRUE) {
    echo "Registration successful. <a href='Donar_Login.php'>Login here</a>";
} else {
    echo "Error: " . $conn->error;
}
?>


